const { initArcState, advanceArc, energyTargetBand, energyJourneyScore, normalizeEnergy, rerankByJourney } = require('./energyJourney');

const results = [];
function check(name, ok, detail) {
  results.push({ name, ok, detail });
  console.log((ok ? 'PASS' : 'FAIL') + ': ' + name + (detail !== undefined ? ' (' + JSON.stringify(detail) + ')' : ''));
}

// ---- arc progression ----
{
  check('starts at warmup', initArcState().phase === 'warmup');
  let s = initArcState();
  s = advanceArc(s); // 1 track into warmup (length 2) -> stays
  check('stays in warmup after 1 track (length 2)', s.phase === 'warmup' && s.tracksInPhase === 1, s);
  s = advanceArc(s); // 2nd track -> advances to build
  check('advances warmup -> build after its length is reached', s.phase === 'build', s);
  s = advanceArc(s); s = advanceArc(s); // build length 2
  check('advances build -> peak', s.phase === 'peak', s);
  s = advanceArc(s); s = advanceArc(s); // peak length 2
  check('advances peak -> release', s.phase === 'release', s);
  s = advanceArc(s); // release length 1
  check('advances release -> build (loops back, skipping warmup)', s.phase === 'build', s);
  // run it around a full extra cycle to confirm it keeps cycling build/peak/release forever
  for (let i = 0; i < 20; i++) s = advanceArc(s);
  check('never returns to warmup once the set has started', (() => {
    let s2 = initArcState();
    for (let i = 0; i < 30; i++) { s2 = advanceArc(s2); if (i > 4 && s2.phase === 'warmup') return false; }
    return true;
  })());
}

// ---- energy target bands are ordered sensibly (peak highest, etc) ----
{
  const bands = ['warmup', 'build', 'peak', 'release'].map((p) => energyTargetBand(p));
  check('peak band sits at the top of the range', energyTargetBand('peak')[1] === 1);
  check('peak band midpoint is higher than warmup band midpoint', (energyTargetBand('peak')[0] + energyTargetBand('peak')[1]) / 2 > (energyTargetBand('warmup')[0] + energyTargetBand('warmup')[1]) / 2);
  check('release band sits below peak', energyTargetBand('release')[1] < energyTargetBand('peak')[0]);
}

// ---- energyJourneyScore ----
{
  check('a value inside the band scores 1', energyJourneyScore(0.8, 'peak') === 1);
  check('a value far outside the band scores near 0', energyJourneyScore(0.05, 'peak') < 0.2, energyJourneyScore(0.05, 'peak'));
  check('a value just outside the band scores close to (but under) 1', energyJourneyScore(0.65, 'peak') < 1 && energyJourneyScore(0.65, 'peak') > 0.8, energyJourneyScore(0.65, 'peak'));
  check('missing energy data is neutral', energyJourneyScore(null, 'peak') === 0.5);
}

// ---- normalizeEnergy ----
{
  check('midpoint normalizes to 0.5', Math.abs(normalizeEnergy(0.15, 0.1, 0.2) - 0.5) < 1e-9);
  check('min normalizes to 0', normalizeEnergy(0.1, 0.1, 0.2) === 0);
  check('max normalizes to 1', normalizeEnergy(0.2, 0.1, 0.2) === 1);
  check('clamps below the observed min', normalizeEnergy(0.05, 0.1, 0.2) === 0);
  check('clamps above the observed max', normalizeEnergy(0.3, 0.1, 0.2) === 1);
  check('a degenerate (flat) library range returns neutral 0.5', normalizeEnergy(0.15, 0.15, 0.15) === 0.5);
}

// ---- rerankByJourney: this is the actual behavior change the person
// asked for — during a warmup phase, a lower-energy candidate should be
// able to beat a slightly-higher-base-score but energy-inappropriate one ----
{
  const candidates = [
    { track: 'loud_but_ok_match', score: 0.82, energyNorm: 0.95 }, // best raw match, but way too hot for warmup
    { track: 'quiet_good_fit', score: 0.75, energyNorm: 0.2 },     // slightly lower raw score, but fits warmup
  ];
  const picked = rerankByJourney(candidates, 'warmup', 0.5);
  check('during warmup, the journey bias can override the single-highest raw score', picked.track === 'quiet_good_fit', picked);

  const pickedNoBias = rerankByJourney(candidates, 'warmup', 0);
  check('with journeyWeight=0, it falls back to pure base score (no behavior change)', pickedNoBias.track === 'loud_but_ok_match', pickedNoBias);

  const pickedDuringPeak = rerankByJourney(candidates, 'peak', 0.5);
  check('the same candidates favor the loud one during peak instead', pickedDuringPeak.track === 'loud_but_ok_match', pickedDuringPeak);

  check('rerankByJourney exposes the journey fit for a transparent reason string', 'journeyFit' in picked && 'finalScore' in picked, picked);
}

console.log(`\n${results.filter((r) => r.ok).length}/${results.length} checks passed`);
const allOk = results.every((r) => r.ok);
console.log('\nENERGYJOURNEY TEST', allOk ? 'PASS' : 'FAIL');
process.exit(allOk ? 0 : 1);
