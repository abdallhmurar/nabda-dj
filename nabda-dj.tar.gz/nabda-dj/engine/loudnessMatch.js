// Approximate perceived-loudness matching between two decks.
//
// Honesty note: this is NOT full ITU-R BS.1770 integrated LUFS (no K-
// weighting filter bank, no gating blocks, no per-channel summing). It's
// a high-pass-filtered RMS-in-dB figure — the high-pass (removing
// sub-40Hz rumble that the ear barely perceives as "loud") is the one
// piece of BS.1770's approach it borrows. Treat the number as "a
// reasonable loudness proxy for comparing two tracks against each
// other", not a broadcast-standard measurement.
//
// It also deliberately does NOT fully normalize: only a fraction of the
// measured difference is corrected, and the correction is capped, so a
// quiet, dynamic track doesn't get slammed up to match a brickwalled
// loud one (which is what "kills dynamics").

function onePoleHighpass(samples, sampleRate, cutoffHz) {
  const dt = 1 / sampleRate, rc = 1 / (2 * Math.PI * cutoffHz), alpha = rc / (rc + dt);
  const out = new Float32Array(samples.length);
  let y = 0, prevX = samples.length ? samples[0] : 0;
  for (let i = 0; i < samples.length; i++) { y = alpha * (y + samples[i] - prevX); prevX = samples[i]; out[i] = y; }
  return out;
}

/** Approximate loudness in dB (see module notes for what this is/isn't). */
function approximateLoudnessDb(samples, sampleRate) {
  if (!samples || !samples.length) return -Infinity;
  const filtered = onePoleHighpass(samples, sampleRate, 40);
  let sum = 0;
  for (let i = 0; i < filtered.length; i++) sum += filtered[i] * filtered[i];
  const rms = Math.sqrt(sum / filtered.length);
  return rms > 1e-9 ? 20 * Math.log10(rms) : -Infinity;
}

function dbToGain(db) { return Math.pow(10, db / 20); }
function gainToDb(gain) { return gain > 1e-9 ? 20 * Math.log10(gain) : -Infinity; }

/**
 * Plans a small, capped gain trim (in dB) to apply to the INCOMING deck
 * so it doesn't land noticeably louder/quieter than the outgoing one.
 * Only partially corrects the measured gap (never fully normalizes) and
 * clamps to +/-maxTrimDb.
 */
function planGainTrim(outgoingLoudnessDb, incomingLoudnessDb, opts) {
  opts = opts || {};
  const maxTrimDb = opts.maxTrimDb == null ? 3 : opts.maxTrimDb;
  const correctionFraction = opts.correctionFraction == null ? 0.7 : opts.correctionFraction;
  if (!isFinite(outgoingLoudnessDb) || !isFinite(incomingLoudnessDb)) {
    return { trimDb: 0, rawDiffDb: 0, clamped: false };
  }
  const rawDiffDb = outgoingLoudnessDb - incomingLoudnessDb; // + if incoming is quieter
  const desired = rawDiffDb * correctionFraction;
  const trimDb = Math.max(-maxTrimDb, Math.min(maxTrimDb, desired));
  return { trimDb, rawDiffDb, clamped: Math.abs(desired) > maxTrimDb + 1e-9 };
}

module.exports = { approximateLoudnessDb, planGainTrim, dbToGain, gainToDb };
